"""Exports a YOLOv5 *.pt model to ONNX and TorchScript formats

Usage:
    $ export PYTHONPATH="$PWD" && python models/export.py --weights ./weights/yolov5s.pt --img 640 --batch 1
"""

import argparse

from models.common import *
from utils import google_utils
import models.yolo as yolo

if __name__ == '__main__':

    # Input
    img = torch.zeros((1, 12, 320, 320))  # image size(1,3,320,192) iDetection

    model = yolo.Model("models/yolov5x.yaml")
    # Load PyTorch model
    model_cc = torch.load("side_epoch_10.pth", map_location=torch.device('cpu')).float()
    model.load_state_dict(model_cc.state_dict())
    model.eval()
    model.model[-1].export = True  # set Detect() layer export=True
    y = model(img)  # dry run

    # ONNX export
    import torch.onnx
    f = "side_epoch_10.onnx"
    model.fuse()  # only for ONNX
    torch.onnx.export(model, img, f, verbose=False, opset_version=11, input_names=['images'])